"""
Step 2 -- Blocking / Candidate Generation.

Produces the exact candidate set the matcher will score
(-> candidate_pairs.tsv). Recall ceiling is set HERE -- a true match
that never becomes a candidate can never be recovered downstream, so
this stage deliberately unions two independent signals rather than
relying on one:

  1. Char n-gram TF-IDF + cosine kNN
     -- cheap, catches typos / abbreviations / word reordering.
  2. Multilingual sentence-embedding + kNN (optional dependency)
     -- this is the main lever for generalizing to France: a
     multilingual embedding model has seen French text in
     pretraining even though it has never seen a single LABELED
     French business-matching example. Pure lexical/TF-IDF
     similarity has no equivalent generalization mechanism, which is
     the main reason this pipeline diverges from a purely
     lexical/country-hardcoded approach.

If sentence-transformers / faiss are not installed, the pipeline
degrades gracefully to TF-IDF-only blocking (lower recall on
unfamiliar formats, but still runs).
"""
from collections import defaultdict

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

try:
    from sentence_transformers import SentenceTransformer
    _EMBEDDINGS_AVAILABLE = True
except ImportError:
    _EMBEDDINGS_AVAILABLE = False

# MIT-licensed. Upgraded from -small to -large: no larger permissively
# licensed embedder exists that would be worth distilling down from, so
# this direct swap (~560M params, still well under the 8B cap) captures
# the available semantic-quality upside for free. Drop back to
# "intfloat/multilingual-e5-small" if this is too slow on your machine.
EMBEDDING_MODEL_NAME = "intfloat/multilingual-e5-large"


def _combined_text(df):
    return (df["name_norm"].fillna("") + " " + df["address_norm"].fillna("")).values


def tfidf_block(df_s1, df_candidates, top_k=15):
    """Char n-gram TF-IDF blocking. df_candidates is S2 or S3 (or both
    concatenated) with an `entity_id` column."""
    texts_s1 = _combined_text(df_s1)
    texts_cand = _combined_text(df_candidates)

    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), min_df=1)
    all_texts = np.concatenate([texts_s1, texts_cand])
    vectorizer.fit(all_texts)

    vec_s1 = vectorizer.transform(texts_s1)
    vec_cand = vectorizer.transform(texts_cand)

    k = min(top_k, len(df_candidates))
    if k == 0:
        return defaultdict(set)
    nn = NearestNeighbors(n_neighbors=k, metric="cosine").fit(vec_cand)
    _, indices = nn.kneighbors(vec_s1)

    cand_ids = df_candidates["entity_id"].values
    s1_ids = df_s1["entity_id"].values
    result = defaultdict(set)
    for i, s1_id in enumerate(s1_ids):
        for idx in indices[i]:
            result[s1_id].add(cand_ids[idx])
    return result


def embedding_block(df_s1, df_candidates, top_k=15, model_name=EMBEDDING_MODEL_NAME):
    """Multilingual embedding blocking. Returns empty result (caller
    should just skip the union) if dependencies are unavailable."""
    if not _EMBEDDINGS_AVAILABLE or len(df_candidates) == 0:
        return defaultdict(set)

    model = SentenceTransformer(model_name)
    texts_s1 = list(_combined_text(df_s1))
    texts_cand = list(_combined_text(df_candidates))

    emb_s1 = model.encode(texts_s1, normalize_embeddings=True, show_progress_bar=False)
    emb_cand = model.encode(texts_cand, normalize_embeddings=True, show_progress_bar=False)

    k = min(top_k, len(df_candidates))
    nn = NearestNeighbors(n_neighbors=k, metric="cosine").fit(emb_cand)
    _, indices = nn.kneighbors(emb_s1)

    cand_ids = df_candidates["entity_id"].values
    s1_ids = df_s1["entity_id"].values
    result = defaultdict(set)
    for i, s1_id in enumerate(s1_ids):
        for idx in indices[i]:
            result[s1_id].add(cand_ids[idx])
    return result


def generate_candidates(df_s1, df_source2, df_source3, top_k=15):
    """Runs both blockers against S2 and S3 separately, unions all
    four candidate sets per S1 entity. Returns dict: s1_entity_id -> set(candidate_ids).
    """
    candidates = defaultdict(set)

    for df_cand in (df_source2, df_source3):
        if len(df_cand) == 0:
            continue
        tfidf_result = tfidf_block(df_s1, df_cand, top_k=top_k)
        emb_result = embedding_block(df_s1, df_cand, top_k=top_k)
        for s1_id in df_s1["entity_id"]:
            candidates[s1_id] |= tfidf_result.get(s1_id, set())
            candidates[s1_id] |= emb_result.get(s1_id, set())

    # Ensure every S1 entity has an entry, even if empty (singleton).
    for s1_id in df_s1["entity_id"]:
        candidates.setdefault(s1_id, set())

    return candidates
